const settings = {
  packname: 'Black tech',
  author: 'Black Tech',
  botName: "Black Tech",
  botOwner: 'black Tech', 
  timezone: 'Africa/Accra',
  prefix: '.',
  ownerNumber: '+254717584694', 
  AUTO_STATUS_REACT: 'true',
  AUTO_STATUS_REPLY: 'false',
  AUTO_STATUS_MSG: 'Status Viewed Black Tech',

  AUTORECORD: 'false',
  AUTOTYPE: 'false',
  AUTORECORDTYPE: 'false',
  

  

  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
};

module.exports = settings;
